package pe.edu.upeu.poo.polimorfismo;

public class Loro extends Animal{
    
    //Aplicación de concepto de polimorfismo
    @Override
    public void sonidoAnimal(){
        System.out.println("Hola Manito Aprende...aprene...esfuerzate");
    }
    
}
