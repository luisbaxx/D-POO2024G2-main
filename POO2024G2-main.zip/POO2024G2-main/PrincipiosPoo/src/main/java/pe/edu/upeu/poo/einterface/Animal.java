/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package pe.edu.upeu.poo.einterface;

/**
 *
 * @author Datos
 */
public interface Animal {
    public void emitirSonido();
    public void dormir();
    
    public String cantar(String nombre);
    

}
