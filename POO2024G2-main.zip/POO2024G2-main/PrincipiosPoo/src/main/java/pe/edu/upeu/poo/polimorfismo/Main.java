
package pe.edu.upeu.poo.polimorfismo;

public class Main {
    
    public static void main(String[] args) {
        Loro objLoro=new Loro();
        objLoro.sonidoAnimal(); 
    }
}
