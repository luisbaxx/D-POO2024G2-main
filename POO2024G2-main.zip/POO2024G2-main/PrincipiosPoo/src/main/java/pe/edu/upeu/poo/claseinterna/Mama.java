package pe.edu.upeu.poo.claseinterna;

public class Mama {
    
    String alimento="Nutrientes...";
    
    //Clase interna
    class Bebe{
        double peso=3;
    }
    
}
