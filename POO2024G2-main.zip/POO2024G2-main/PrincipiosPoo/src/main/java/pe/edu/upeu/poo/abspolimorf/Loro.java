
package pe.edu.upeu.poo.abspolimorf;

public class Loro extends Animal{

    @Override
    public void animalSound() {
        System.out.println("Esto es Polimorfismo entiende pue!!");
    }
    
    @Override
    public void sleep(){
        System.out.println("Esta clase no me gusta me da Zzz zz..");
    }    
}
