package pe.edu.upeu.poo.polimorfismo;

public class Animal {
    public void sonidoAnimal(){
        System.out.println("El animal hace sonido");
    }
}
